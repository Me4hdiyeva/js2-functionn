let email = prompt('Enter your email:');


if(email== ('admin@gmail.com')){
    answer=true;
} else{
    answer=false ;

}
alert(answer)

let pass =  prompt('Enter your password:');

if (pasword== ('1234567')){
    answer = true ;
}else{
    answer = false ;
}
alert(answer)

function button (){

    alert('yanlısdır');
}

